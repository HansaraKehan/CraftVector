# Android layer news

<!-- Newest section first. The release uses ONLY the first "## " section, and only once.
     "- " = new feature, "* " = fix. Never mention Discord. Write @names inside backticks. -->

## Android build 4

- **Pen & Touch, brought over from PhotoCraft.** Stylus barrel buttons (press, press twice, press three times, hold), a soft-key strip (Undo, Redo, Ctrl, Alt, Shift, Enter, Esc, editable, top or bottom) and a Finger / Pen only switch. Pen only: fingers never draw, one finger pans, two fingers pan, zoom and rotate. On a screen with an active stylus a finger drag moves things while the pen keeps drawing. Open the gear in the strip for every setting.
- **Quick tour.** A short animated guide opens on first launch and points at the buttons it talks about. Replay it from Help > Quick tour: pen and touch.
- **Two- and three-finger taps (Pen only mode).** Each has its own on/off switch and an action: any key combination or command. Default: Undo and Redo.
- **Check for Updates** is in the Help menu, besides the automatic check at start (Download / Remind me later / Skip this version).
* Pen button double and triple presses now work while the pen hovers. The wait between presses is 500 ms by default.
* Scrolling: a quick vertical swipe scrolls panels and windows (Layers, Swatches, dialogs), not only the thin scroll bar.
* The Pen & Touch window opens quickly.
