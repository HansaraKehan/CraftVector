//! VectorCraft for Android: runs the shared egui UI (`vectorcraft-ui-egui`) inside a NativeActivity.
//!
//! - Open / Save As / Export use Android's own file picker (no storage permission): the Java activity
//!   copies the chosen document to a private folder, VectorCraft works on that copy, and every later
//!   save is written back to the original location.
//! - Web links open in the browser through the Java activity; documents other apps open with
//!   VectorCraft arrive the same way.
//! - Preferences, libraries and Data Recovery live in the app's private folder.
//! - Pen & Touch (`pen_touch`): stylus buttons, soft keys, Finger / Pen only, swipe scrolling.
//! - Not yet: system clipboard, printing, folder export without "All files access".
#![cfg(target_os = "android")]

mod pen_touch;
mod update;

use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex, mpsc};
use std::time::Duration;

use android_activity::AndroidApp;
use jni::{
    JNIEnv, JavaVM,
    objects::{JObject, JString, JValue},
};
use vectorcraft_engine::Session;
use vectorcraft_engine::cmd::fileio;
use vectorcraft_ui_egui::picks::{PickAnswer, PickRequest};
use vectorcraft_ui_egui::{Services, UiState, VectorcraftApp};

/// The answer channel of a dialog that is open in Android's own picker.
static EXTERNAL: Mutex<Option<mpsc::Sender<PickAnswer>>> = Mutex::new(None);

struct App {
    app: VectorcraftApp,
    android: AndroidApp,
    prefs: Option<PathBuf>,
    updates: update::Updates,
    pen: pen_touch::PenTouch,
    /// False once a Pen & Touch hook panicked: that feature stays off, the editor keeps running.
    pen_ok: bool,
    /// What made the app stop last time (read from `last-panic.txt`), shown once.
    crash_note: Option<(String, Option<PathBuf>)>,
    /// Frames run so far. The app installs its fonts on frame 1 and egui applies them on frame 2;
    /// text drawn before that panics (the families are not bound yet), so our UI waits.
    frames: u32,
}

/// Run a Pen & Touch hook; if it panics, switch the feature off instead of closing the app.
fn guard(ok: &mut bool, f: impl FnOnce()) {
    if *ok && std::panic::catch_unwind(std::panic::AssertUnwindSafe(f)).is_err() {
        *ok = false;
    }
}

/// The message of the latest panic, for the window that says Pen & Touch switched itself off.
static LAST_PANIC: Mutex<String> = Mutex::new(String::new());

/// Remember a panic in a file, so the next start can show what happened.
fn install_panic_log(dir: Option<PathBuf>) {
    let file = dir.map(|d| d.join("last-panic.txt"));
    let previous = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        if let Ok(mut last) = LAST_PANIC.lock() {
            *last = info.to_string();
        }
        if let Some(file) = &file {
            let _ = std::fs::write(file, info.to_string());
        }
        previous(info);
    }));
}

impl eframe::App for App {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.frames = self.frames.saturating_add(1);
        if let Some(path) = poll_open(&self.android)
            && let Err(error) = vectorcraft_ui_egui::io::open_reporting(&mut self.app, &path)
        {
            log::warn!("open {path}: {error}");
        }
        if let Some(answer) = poll_pick(&self.android)
            && let Ok(mut waiting) = EXTERNAL.lock()
            && let Some(tx) = waiting.take()
        {
            let _ = tx.send(answer);
        }
        guard(&mut self.pen_ok, || pen_touch::logic(&mut self.pen, &mut self.app, ctx));
        self.app.logic(ctx);
        self.updates.tick();
        // Wake now and then to see a document another app handed us, or a picker answer.
        ctx.request_repaint_after(Duration::from_millis(700));
    }
    fn raw_input_hook(&mut self, ctx: &egui::Context, raw: &mut egui::RawInput) {
        // Pen buttons, soft keys, Pen only mode and swipe scrolling add and rewrite input first.
        guard(&mut self.pen_ok, || pen_touch::raw_input(&mut self.pen, &mut self.app, ctx, raw));
        self.app.raw_input_hook(raw);
    }
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        let ready = self.frames >= 3;
        // The strip goes first, so the app's own bars sit beside it, not under it.
        if ready {
            guard(&mut self.pen_ok, || pen_touch::ui::strip(&mut self.pen, ui));
        }
        self.app.ui(ui);
        let ctx = ui.ctx().clone();
        if !ready {
            ctx.request_repaint();
            open_links(ui.ctx(), &self.android);
            return;
        }
        let mut check = false;
        guard(&mut self.pen_ok, || {
            pen_touch::ui::prompt(&mut self.pen, &ctx);
            check = pen_touch::ui::settings_window(&mut self.pen, &self.app, &ctx, self.updates.status());
            pen_touch::paint_pen_pointer(&self.pen, &self.app, &ctx);
        });
        if check {
            self.updates.check_now();
        }
        if !self.pen_ok {
            let text = LAST_PANIC.lock().map(|t| t.clone()).unwrap_or_default();
            egui::Window::new("Pen & Touch switched itself off").collapsible(false).show(&ctx, |ui| {
                ui.label("Something failed in the pen and touch code. Please send this text to the developer:");
                ui.label(text.as_str());
            });
        }
        if let Some((text, _)) = self.crash_note.clone() {
            let mut close = false;
            guard(&mut self.pen_ok, || {
                egui::Window::new("VectorCraft stopped last time").collapsible(false).show(&ctx, |ui| {
                    ui.label("Please send this text to the developer:");
                    ui.label(text.as_str());
                    if ui.button("OK").clicked() {
                        close = true;
                    }
                });
            });
            if close || !self.pen_ok {
                self.crash_note = None;
            }
        }
        open_links(ui.ctx(), &self.android);
        // Written when confirmed, not at exit: Android may end the app at any time.
        if self.app.take_prefs_changed() {
            save_prefs(&self.app, self.prefs.as_deref());
        }
    }
}

fn load_prefs(path: &Path) -> Option<UiState> {
    let bytes = std::fs::read(path).ok()?;
    let mut value: serde_json::Value = serde_json::from_slice(&bytes).ok()?;
    if let Ok(ui) = serde_json::from_value::<UiState>(value.clone()) {
        return Some(ui);
    }
    // A panel layout that no longer fits: drop only that, keep the other settings.
    if let Some(fields) = value.as_object_mut() {
        for key in ["docking", "docking_hidden", "custom_workspaces"] {
            fields.remove(key);
        }
    }
    serde_json::from_value(value).ok()
}

fn save_prefs(app: &VectorcraftApp, path: Option<&Path>) {
    let Some(path) = path else { return };
    let _ = std::fs::create_dir_all(path.parent().unwrap_or(Path::new(".")));
    let mut ui = app.ui.clone();
    ui.engine_prefs = app.session.prefs.to_json();
    if let Ok(bytes) = serde_json::to_vec_pretty(&ui) {
        // Preferences are best effort: a failed write keeps the previous file.
        let _ = fileio::write_atomic(path, &bytes);
    }
}

fn write_file(path: &str, bytes: &[u8]) -> Result<(), String> {
    fileio::write_atomic(Path::new(path), bytes).map_err(|e| e.to_string())
}

/// The fonts Android ships, for the font lists and text rendering.
fn android_font_files() -> Vec<String> {
    let mut files = Vec::new();
    for dir in ["/system/fonts", "/system/product/fonts", "/product/fonts", "/system_ext/fonts"] {
        let Ok(read) = std::fs::read_dir(dir) else { continue };
        for entry in read.flatten() {
            let path = entry.path();
            let ext = path.extension().and_then(|e| e.to_str()).map(str::to_lowercase);
            if matches!(ext.as_deref(), Some("ttf" | "otf" | "ttc")) {
                files.push(path.to_string_lossy().into_owned());
            }
        }
    }
    files
}

/// Run `f` on the Java activity from this thread.
#[allow(unsafe_code)]
pub(crate) fn with_activity<R>(app: &AndroidApp, f: impl FnOnce(&mut JNIEnv<'_>, &JObject<'_>) -> jni::errors::Result<R>) -> Option<R> {
    // SAFETY: android_main is called with the VM owned by Android for this process.
    let vm = unsafe { JavaVM::from_raw(app.vm_as_ptr().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    // SAFETY: AndroidApp keeps this global reference to the activity alive; we only borrow it.
    let activity = unsafe { JObject::from_raw(app.activity_as_ptr().cast()) };
    match env.with_local_frame(16, |env| f(env, &activity)) {
        Ok(value) => Some(value),
        Err(_) => {
            let _ = env.exception_clear();
            None
        }
    }
}

fn read_string(app: &AndroidApp, method: &str) -> Option<String> {
    with_activity(app, |env, activity| {
        let value = env.call_method(activity, method, "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let out: String = env.get_string(&text)?.into();
        Ok(out)
    })
}

/// The next document another app opened with us (a file path), if any.
fn poll_open(app: &AndroidApp) -> Option<String> {
    read_string(app, "pollOpen").filter(|path| !path.is_empty())
}

/// The picker's answer once it has closed: the chosen paths (none = cancelled).
fn poll_pick(app: &AndroidApp) -> Option<PickAnswer> {
    let answer = read_string(app, "pollPick").filter(|a| !a.is_empty())?;
    Some(answer.strip_prefix("OK\n").map(|paths| paths.split('\n').filter(|p| !p.is_empty()).map(str::to_string).collect()).unwrap_or_default())
}

/// Show Android's file picker. kind: 0 open one, 1 open several, 2 save, 3 folder.
fn show_picker(app: &AndroidApp, kind: i32, name: &str) -> bool {
    with_activity(app, |env, activity| {
        let name = env.new_string(name)?;
        env.call_method(activity, "startPick", "(ILjava/lang/String;)V", &[JValue::Int(kind), JValue::from(&name)])?;
        Ok(())
    })
    .is_some()
}

/// `Services::start_pick`: the dialog is shown off the UI thread and answers on the receiver.
fn start_pick(app: &AndroidApp, request: PickRequest) -> Option<mpsc::Receiver<PickAnswer>> {
    let (kind, name) = match &request {
        PickRequest::Open(_) => (0, String::new()),
        PickRequest::OpenMany => (1, String::new()),
        PickRequest::Save(pick) => (2, pick.name.clone()),
        PickRequest::Folder => (3, String::new()),
    };
    if !show_picker(app, kind, &name) {
        return None;
    }
    let (tx, rx) = mpsc::channel();
    *EXTERNAL.lock().ok()? = Some(tx);
    Some(rx)
}

/// Open a web link in the user's browser.
pub(crate) fn open_link(app: &AndroidApp, url: &str) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(url)?;
        env.call_method(activity, "openLink", "(Ljava/lang/String;)V", &[JValue::from(&text)])?;
        Ok(())
    })
    .is_some()
}

/// Links drawn with `ui.hyperlink` ask egui to open them; do that here.
fn open_links(ctx: &egui::Context, app: &AndroidApp) {
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::OpenUrl(open) => {
                open_link(app, &open.url);
                false
            }
            _ => true,
        });
    });
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("VectorCraft").with_max_level(log::LevelFilter::Info));
    let private = app.internal_data_path();
    install_panic_log(private.clone());
    vectorcraft_text::set_platform_font_files(android_font_files);
    let android = app.clone();
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "VectorCraft",
        options,
        Box::new(move |cc| {
            let picker = android.clone();
            let opener = android.clone();
            let services = Services {
                // `can` asks for these; the dialogs themselves are shown by `start_pick`.
                pick_open: Some(Box::new(|_| None)),
                pick_open_multi: Some(Box::new(Vec::new)),
                pick_save: Some(Box::new(|_| None)),
                pick_folder: Some(Box::new(|| None)),
                start_pick: Some(Box::new(move |request: PickRequest| start_pick(&picker, request))),
                read: Some(Box::new(|p: &str| std::fs::read(p).map_err(|e| e.to_string()))),
                write: Some(Box::new(write_file)),
                write_shared: Some(Arc::new(write_file)),
                stream_shared: Some(Arc::new(|p: &str, fill: &mut dyn FnMut(&mut dyn std::io::Write) -> std::io::Result<()>| {
                    fileio::write_file_with(p, fill).map_err(|e| e.to_string())
                })),
                open_url: Some(Box::new(move |url: &str| {
                    open_link(&opener, url);
                })),
                ..Default::default()
            };
            let mut app = VectorcraftApp::new(Session::new(), services);
            let prefs = private.as_ref().map(|dir| dir.join("prefs.json"));
            if let Some(ui) = prefs.as_deref().and_then(load_prefs) {
                app.ui = ui.sanitized();
            }
            vectorcraft_ui_egui::prefs_dialog::restore(&mut app);
            if let Some(dir) = &private {
                let sub = |name: &str| Some(dir.join(name).to_string_lossy().to_string());
                app.session.swatch_libraries.set_user_dir(sub("Swatches"));
                app.session.style_libraries.set_user_dir(sub("Graphic Styles"));
                app.session.libraries.set_dir(sub("Libraries"));
                app.session.recovery.set_default_folder(sub("Data Recovery"));
            }
            // No window frame to draw buttons into: Android owns the window.
            app.custom_titlebar = false;
            let updates = update::Updates::new(android.clone(), private.as_deref());
            let pen = pen_touch::PenTouch::load(private.as_ref().map(|dir| dir.join("pen_touch.json")));
            let note_file = private.as_ref().map(|dir| dir.join("last-panic.txt"));
            let crash_note = note_file.as_ref().and_then(|f| std::fs::read_to_string(f).ok()).filter(|t| !t.is_empty()).map(|t| (t, note_file.clone()));
            // Read once: a note left behind must never be able to stop the next start.
            if let Some(f) = &note_file {
                let _ = std::fs::remove_file(f);
            }
            Ok(Box::new(App { app, android, prefs, updates, pen, pen_ok: true, crash_note, frames: 0 }))
        }),
    );
    if let Err(error) = result {
        log::error!("VectorCraft failed to start: {error}");
    }
}
