//! Pen & Touch screens: the start-up question, the soft-key strip, and the settings window.
//! Labels are plain English for now.

use egui::{RichText, Ui, vec2};
use vectorcraft_ui_egui::VectorcraftApp;

use super::PenTouch;
use super::settings::{DeviceKind, InputMode, MAX_SOFT_KEYS, PenButtonCfg, SoftKey, StripPlace, default_soft_keys};
use super::virtual_keys;

/// State of the start-up question.
#[derive(Debug, Default)]
pub struct Prompt {
    /// The question was answered or skipped this session.
    done: bool,
    /// The option picked so far.
    choice: Option<DeviceKind>,
}

// ------------------------------------------------------------------ start-up question

/// Ask once per launch which kind of device this is, unless the user said not to.
pub fn prompt(pt: &mut PenTouch, ctx: &egui::Context) {
    if pt.prompt.done {
        return;
    }
    if !pt.settings.ask_at_start {
        pt.prompt.done = true;
        return;
    }
    let current = match pt.settings.device {
        DeviceKind::Unset => DeviceKind::Touch,
        d => d,
    };
    let mut choice = pt.prompt.choice.unwrap_or(current);
    let mut answer: Option<bool> = None; // Some(dont_ask_again)
    egui::Modal::new(egui::Id::new("pen-touch-device-question")).show(ctx, |ui| {
        ui.set_max_width(360.0);
        ui.heading("Which device are you using?");
        ui.add_space(4.0);
        ui.label("VectorCraft adapts touch and pen input to your screen. You can change this later in the Pen & Touch window (the gear in the strip).");
        ui.add_space(8.0);
        ui.radio_value(&mut choice, DeviceKind::ActiveStylus, "Device with an active stylus");
        ui.label(RichText::new("The pen draws and fingers move things.").weak().small());
        ui.add_space(4.0);
        ui.radio_value(&mut choice, DeviceKind::Touch, "Device without an active stylus");
        ui.label(RichText::new("Fingers draw. Nothing presses Enter for you.").weak().small());
        ui.add_space(10.0);
        ui.horizontal(|ui| {
            if ui.add(egui::Button::new("Continue").min_size(vec2(110.0, 40.0))).clicked() {
                answer = Some(false);
            }
            if ui.add(egui::Button::new("Don't ask again").min_size(vec2(130.0, 40.0))).clicked() {
                answer = Some(true);
            }
        });
    });
    pt.prompt.choice = Some(choice);
    if let Some(dont_ask) = answer {
        pt.settings.device = choice;
        if dont_ask {
            pt.settings.ask_at_start = false;
        }
        pt.prompt.done = true;
    }
}

// ------------------------------------------------------------------ soft keys

/// What the strip's buttons asked for this frame.
#[derive(Default)]
struct StripActions {
    toggle: bool,
    mode: bool,
    settings: bool,
}

/// The strip's buttons: the contract handle, the Finger / Pen only switch, the soft keys and the
/// settings gear.
fn strip_contents(pt: &mut PenTouch, ui: &mut Ui) -> StripActions {
    let mut a = StripActions::default();
    let open = pt.settings.soft_keys_open;
    let show_keys = open && pt.settings.soft_keys_visible;
    ui.spacing_mut().item_spacing.x = 4.0;
    let handle = if open { "«" } else { "»" };
    if ui
        .add(egui::Button::new(handle).min_size(vec2(30.0, 34.0)))
        .on_hover_text(if open { "Contract the soft keys" } else { "Show the soft keys" })
        .clicked()
    {
        a.toggle = true;
    }
    let pen_only = pt.stylus_only();
    if ui
        .add(egui::Button::new(if pen_only { "Pen only" } else { "Finger" }).selected(pen_only).min_size(vec2(72.0, 34.0)))
        .on_hover_text(if pen_only {
            "Pen only: fingers never draw; one finger pans the canvas, two fingers pan, zoom and rotate it. Tap for Finger mode."
        } else {
            "Finger mode: fingers and the pen both draw. Tap for Pen only."
        })
        .clicked()
    {
        a.mode = true;
    }
    if ui.add(egui::Button::new("⚙").min_size(vec2(34.0, 34.0))).on_hover_text("Pen & Touch settings").clicked() {
        a.settings = true;
    }
    if !show_keys {
        return a;
    }
    egui::ScrollArea::horizontal().id_salt("soft-key-scroll").auto_shrink([false, true]).show(ui, |ui| {
        ui.horizontal(|ui| {
            ui.spacing_mut().item_spacing.x = 4.0;
            let keys = pt.settings.soft_keys.clone();
            for key in &keys {
                soft_key_button(pt, ui, key);
            }
        });
    });
    a
}

/// The strip at the top (or bottom) of the screen: the Finger / Pen only switch and the soft keys.
/// It contracts to a thin handle (the switch and the gear stay). Call before the app's own `ui`.
pub fn strip(pt: &mut PenTouch, ui: &mut Ui) {
    let show_keys = pt.settings.soft_keys_open && pt.settings.soft_keys_visible;
    let height = if show_keys { 44.0 } else { 40.0 };
    let panel = match pt.settings.strip_place {
        StripPlace::Top => egui::Panel::top("pen_touch_strip"),
        StripPlace::Bottom => egui::Panel::bottom("pen_touch_strip"),
    };
    let fill = ui.visuals().panel_fill;
    let mut actions = StripActions::default();
    panel
        .exact_size(height)
        .frame(egui::Frame::NONE.fill(fill).inner_margin(egui::Margin { left: 6, right: 6, top: 3, bottom: 3 }))
        .show(ui, |ui| {
            ui.horizontal_centered(|ui| actions = strip_contents(pt, ui));
        });
    if actions.toggle {
        pt.settings.soft_keys_open = !pt.settings.soft_keys_open;
    }
    if actions.mode {
        pt.toggle_input_mode();
    }
    if actions.settings {
        pt.window_open = !pt.window_open;
    }
}

/// One soft key. Modifier keys latch (tap to hold, tap again to let go); the other keys are held
/// while the finger is down, so a hold works (Space for the Hand tool) and a quick tap is one press.
fn soft_key_button(pt: &mut PenTouch, ui: &mut Ui, key: &SoftKey) {
    let spec = key.keys.trim();
    if spec.is_empty() {
        return;
    }
    let size = vec2(46.0, 34.0);
    if spec == super::settings::RECENT {
        if ui.add(egui::Button::new(key.caption()).min_size(size)).on_hover_text("Switch to the previous tool").clicked() {
            pt.switch_to_recent_tool();
        }
        return;
    }
    let modifier = super::buttons::is_modifier_only(spec);
    let latched = modifier && pt.keys.is_latched(spec);
    let held = !modifier && pt.keys.is_held(spec);
    let resp = ui.add(egui::Button::new(key.caption()).selected(latched || held).min_size(size)).on_hover_text(spec);
    if modifier {
        if resp.clicked() {
            pt.keys.latch(spec);
        }
        return;
    }
    let down = resp.is_pointer_button_down_on();
    if down && !held {
        pt.keys.press(spec);
    } else if !down && held {
        pt.keys.release(spec);
    } else if resp.clicked() && !held {
        pt.keys.tap(spec);
    }
}

// ------------------------------------------------------------------ settings window

/// Basic keys the Pick menu offers.
const BASIC_KEYS: [&str; 14] =
    ["Ctrl", "Alt", "Shift", "Ctrl+Shift", "Ctrl+Alt", "Alt+Shift", "Space", "Enter", "Escape", "Tab", "Delete", "Backspace", "[", "]"];

/// The Pen & Touch window. Changes apply at once. `update_status` is shown under "Updates"; the
/// result is true when "Check for updates now" was pressed.
pub fn settings_window(pt: &mut PenTouch, app: &VectorcraftApp, ctx: &egui::Context, _update_status: &str) -> bool {
    if !pt.window_open {
        pt.command_cache = None;
        return false;
    }
    // Building the command list is slow: once per opening, not once per frame.
    let commands = pt.command_cache.take().unwrap_or_else(|| command_keys(app));
    let mut s = pt.settings.clone();
    let mut open = true;
    let mut check = false;
    let area = ctx.content_rect();
    egui::Window::new("Pen & Touch")
        .open(&mut open)
        .collapsible(false)
        .default_width((area.width() - 32.0).clamp(260.0, 520.0))
        .max_height((area.height() - 24.0).max(200.0))
        .show(ctx, |ui| {
            egui::ScrollArea::vertical().id_salt("pen-touch-window").auto_shrink([false, true]).show(ui, |ui| {
                ui.label(RichText::new("These settings apply immediately.").weak().small());

                ui.add_space(4.0);
                ui.label(RichText::new("Device").strong());
                ui.radio_value(&mut s.device, DeviceKind::ActiveStylus, "With an active stylus");
                ui.radio_value(&mut s.device, DeviceKind::Touch, "Without an active stylus");
                ui.checkbox(&mut s.ask_at_start, "Ask which device this is when the app starts");

                for (n, cfg) in [(1, &mut s.button1), (2, &mut s.button2)] {
                    ui.add_space(6.0);
                    pen_button_block(ui, n, cfg, &commands);
                }

                ui.add_space(6.0);
                ui.label(RichText::new("Input mode").strong());
                ui.label(RichText::new("The Finger / Pen only button in the strip switches quickly.").weak().small());
                ui.radio_value(&mut s.input_mode, InputMode::Finger, "Finger: fingers and pen draw");
                ui.radio_value(&mut s.input_mode, InputMode::StylusOnly, "Pen only: only the pen draws");
                ui.add_enabled_ui(s.stylus_only(), |ui| {
                    ui.checkbox(&mut s.stylus_only_zoom, "Two fingers zoom the canvas");
                    ui.checkbox(&mut s.stylus_only_rotate, "Two fingers rotate the canvas");
                    ui.checkbox(&mut s.stylus_only_pan, "Fingers pan the canvas (one finger, or two)");
                });
                ui.add_enabled_ui(s.stylus_only(), |ui| {
                    ui.checkbox(&mut s.finger_tap2_on, "A quick tap of two fingers does an action");
                    ui.add_enabled_ui(s.finger_tap2_on, |ui| shortcut_row(ui, "tap2", "Two fingers", &mut s.finger_tap2, &commands));
                    ui.checkbox(&mut s.finger_tap3_on, "A quick tap of three fingers does an action");
                    ui.add_enabled_ui(s.finger_tap3_on, |ui| shortcut_row(ui, "tap3", "Three fingers", &mut s.finger_tap3, &commands));
                });
                ui.label(RichText::new("Pen only. The action is any key combination or command (Pick); \"@recent\" switches tools.").weak().small());

                ui.add_space(6.0);
                ui.label(RichText::new("Panels and windows").strong());
                ui.checkbox(&mut s.touch_scroll, "Swipe up or down on a list row, swatch or slider to scroll the panel or window");
                ui.checkbox(&mut s.touch_comfort, "Larger touch targets (taller buttons and fields)");

                ui.add_space(6.0);
                ui.label(RichText::new("Pen pointer").strong());
                ui.checkbox(&mut s.show_pen_pointer, "Show a pointer ring where the pen is (hovering and touching)");
                ui.add_enabled_ui(s.show_pen_pointer, |ui| {
                    ui.checkbox(&mut s.pen_pointer_follows_brush, "Match the Blob Brush and Eraser size automatically");
                    ui.horizontal(|ui| {
                        ui.label(if s.pen_pointer_follows_brush { "Size for other tools" } else { "Pointer size" });
                        ui.add(egui::Slider::new(&mut s.pen_pointer_size, 8.0..=120.0).suffix(" pt"));
                    });
                });

                ui.add_space(6.0);
                ui.label(RichText::new("Fingers on an active-stylus screen").strong());
                ui.add_enabled_ui(s.device.has_active_stylus(), |ui| {
                    ui.checkbox(&mut s.finger_move, "A finger drag moves the item (the pen keeps drawing; Finger mode)");
                });
                if !s.device.has_active_stylus() {
                    ui.label(RichText::new("Choose \"With an active stylus\" to use this.").weak().small());
                }

                ui.add_space(6.0);
                ui.label(RichText::new("Soft keys").strong());
                ui.checkbox(&mut s.soft_keys_visible, "Show the soft keys in the strip");
                ui.horizontal(|ui| {
                    ui.label("Strip position");
                    ui.radio_value(&mut s.strip_place, StripPlace::Top, "Top");
                    ui.radio_value(&mut s.strip_place, StripPlace::Bottom, "Bottom");
                });
                soft_keys_editor(ui, &mut s.soft_keys, &commands);

            });
        });
    pt.command_cache = Some(commands);
    pt.window_open = open;
    if s != pt.settings {
        let buttons_changed = s.button1 != pt.settings.button1 || s.button2 != pt.settings.button2 || s.device != pt.settings.device;
        pt.settings = s;
        if buttons_changed {
            pt.release_held();
        }
    }
    check
}

fn pen_button_block(ui: &mut Ui, n: usize, cfg: &mut PenButtonCfg, commands: &[(String, String)]) {
    ui.label(RichText::new(format!("Pen button {n}")).strong());
    ui.checkbox(&mut cfg.enabled, "Use this button");
    ui.add_enabled_ui(cfg.enabled, |ui| {
        shortcut_row(ui, &format!("b{n}-tap"), "Press", &mut cfg.tap, commands);
        ui.add_enabled(
            ![&cfg.tap, &cfg.double, &cfg.triple].iter().all(|k| k.trim().is_empty() || k.trim() == super::settings::RECENT),
            egui::Checkbox::new(&mut cfg.tap_toggles_back, "Doing the same press again returns to the previous tool"),
        );
        shortcut_row(ui, &format!("b{n}-double"), "Press twice", &mut cfg.double, commands);
        shortcut_row(ui, &format!("b{n}-triple"), "Press 3 times", &mut cfg.triple, commands);
        shortcut_row(ui, &format!("b{n}-hold"), "Hold", &mut cfg.hold, commands);
        ui.horizontal_wrapped(|ui| {
            ui.label("Hold after");
            ui.add(egui::DragValue::new(&mut cfg.hold_ms).range(100..=3000).suffix(" ms"));
            ui.label("  Next press within");
            ui.add(egui::DragValue::new(&mut cfg.multi_ms).range(150..=800).suffix(" ms"));
        });
        ui.label(
            RichText::new("Ctrl, Alt, Shift: one press holds it, the next lets go. Hold keys stay down while the button is held. \"@recent\" switches between the last two tools.")
                .weak()
                .small(),
        );
    });
}

/// `label`, a key combination field with Record and Pick, and a warning for a combination that can't be pressed.
fn shortcut_row(ui: &mut Ui, id: &str, label: &str, keys: &mut String, commands: &[(String, String)]) {
    ui.horizontal_wrapped(|ui| {
        ui.label(label);
        keys_editor(ui, egui::Id::new(("pen-touch-keys", id)), keys, commands);
    });
}

/// A key combination field: type it, record it from the keyboard, or pick one.
fn keys_editor(ui: &mut Ui, id: egui::Id, keys: &mut String, commands: &[(String, String)]) {
    let valid = virtual_keys::is_valid(keys);
    let mut edit = egui::TextEdit::singleline(keys).desired_width(120.0).hint_text("Ctrl+Shift+Z");
    if !valid {
        edit = edit.text_color(egui::Color32::LIGHT_RED);
    }
    ui.add(edit);

    let rec_id = id.with("record");
    let recording = ui.data(|d| d.get_temp::<bool>(rec_id)).unwrap_or(false);
    if ui.selectable_label(recording, if recording { "Press a key…" } else { "Record" }).clicked() {
        ui.data_mut(|d| d.insert_temp(rec_id, !recording));
    }
    if recording {
        let got = ui.input(|i| {
            i.events.iter().find_map(|e| match e {
                egui::Event::Key { key, pressed: true, modifiers, .. } => vectorcraft_ui_egui::shortcut_editor::chord_from_event(*key, *modifiers),
                _ => None,
            })
        });
        if let Some(text) = got {
            *keys = text;
            ui.data_mut(|d| d.insert_temp(rec_id, false));
        }
        ui.ctx().request_repaint();
    }

    ui.menu_button("Pick", |ui| {
        ui.set_min_width(220.0);
        if ui.button("Switch between recent tools").clicked() {
            *keys = super::settings::RECENT.to_string();
            ui.close();
        }
        ui.separator();
        for k in BASIC_KEYS {
            if ui.button(k).clicked() {
                *keys = k.to_string();
                ui.close();
            }
        }
        if !commands.is_empty() {
            ui.separator();
            let filter_id = id.with("filter");
            let mut filter = ui.data(|d| d.get_temp::<String>(filter_id)).unwrap_or_default();
            ui.add(egui::TextEdit::singleline(&mut filter).hint_text("Search tools and commands…").desired_width(200.0));
            let needle = filter.trim().to_lowercase();
            ui.data_mut(|d| d.insert_temp(filter_id, filter));
            egui::ScrollArea::vertical().max_height(220.0).id_salt("pick-commands").show(ui, |ui| {
                for (label, sc) in
                    commands.iter().filter(|(l, s)| needle.is_empty() || l.to_lowercase().contains(&needle) || s.to_lowercase().contains(&needle)).take(80)
                {
                    if ui.button(format!("{label}   {sc}")).clicked() {
                        *keys = sc.clone();
                        ui.close();
                    }
                }
            });
        }
    });
    if !valid {
        ui.label(RichText::new("Unknown key").color(egui::Color32::LIGHT_RED).small());
    }
}

/// The list of soft keys: edit, remove, add, reset.
fn soft_keys_editor(ui: &mut Ui, keys: &mut Vec<SoftKey>, commands: &[(String, String)]) {
    let mut remove: Option<usize> = None;
    for (i, key) in keys.iter_mut().enumerate() {
        ui.horizontal_wrapped(|ui| {
            ui.add(egui::TextEdit::singleline(&mut key.label).desired_width(70.0).hint_text("Label"));
            keys_editor(ui, egui::Id::new(("pen-touch-soft", i)), &mut key.keys, commands);
            if ui.small_button("Remove").clicked() {
                remove = Some(i);
            }
        });
    }
    if let Some(i) = remove {
        keys.remove(i);
    }
    ui.horizontal(|ui| {
        if ui.add_enabled(keys.len() < MAX_SOFT_KEYS, egui::Button::new("Add key")).clicked() {
            keys.push(SoftKey::new("Key", "Enter"));
        }
        if ui.button("Reset soft keys").clicked() {
            *keys = default_soft_keys();
        }
    });
    ui.label(RichText::new("Ctrl, Alt, Shift: tap to hold, tap again to let go. Other keys are pressed while you touch them.").weak().small());
}

/// Tools and commands that have a shortcut: label and effective shortcut, for the Pick menu.
fn command_keys(app: &VectorcraftApp) -> Vec<(String, String)> {
    let mut out: Vec<(String, String)> = vectorcraft_ui_egui::shortcut_editor::entries()
        .iter()
        .filter_map(|e| {
            let sc = vectorcraft_ui_egui::shortcut_editor::effective_in(&app.ui.shortcut_overrides, &e.key)?;
            (!sc.is_empty() && virtual_keys::is_valid(&sc)).then(|| (e.label.clone(), sc))
        })
        .collect();
    out.sort();
    out.dedup();
    out
}
