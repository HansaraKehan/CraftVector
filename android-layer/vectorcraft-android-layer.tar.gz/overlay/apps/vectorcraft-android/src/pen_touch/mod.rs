//! Pen & Touch for the Android edition: stylus barrel buttons, simulated key presses, the
//! Finger / Pen only input mode, finger behaviour on active-stylus screens, swipe scrolling in
//! panels and windows, the soft-key strip and a pointer ring.
//!
//! Everything works by *adding input* before egui's frame runs ([`raw_input`]), so the editor's own
//! shortcut handling stays the one place that decides what a key does. It uses only the public API
//! of `vectorcraft-ui-egui` (no edits to upstream code), so upstream changes cannot break it
//! silently.
//!
//! - [`virtual_keys`]: simulated key presses and latched modifiers.
//! - [`buttons`]: the barrel button state machine (tap, hold, toggle back to the previous tool).
//! - [`gestures`]: two-finger pan, pinch and twist from raw touch contacts.
//! - [`settings`]: what is stored in `pen_touch.json`.
//! - [`ui`]: the strip, the settings window and the start-up question.
//!
//! The Android window layer (the vendored winit) reports the stylus barrel buttons as the mouse's
//! *Back* (first button) and *Forward* (second button) buttons, and puts [`PEN_TOUCH_FLAG`] (or
//! [`ERASER_TOUCH_FLAG`]) in the touch id of a stylus contact, so a pen is told from a finger.
//!
//! **Pen only mode**: a finger that lands on the canvas never reaches the tools; one finger pans
//! the view and two fingers pan, zoom and rotate it about their midpoint. A tap of two fingers
//! undoes and one of three redoes (as with Enable Touch Gestures). Fingers on the panels, menus
//! and floating windows work as usual. The pen's own pointer events are rebuilt from its touch
//! events while a finger or palm is down, because egui follows only the first contact.
//!
//! **Swipe scrolling**: a quick vertical swipe that starts on a list row, thumbnail, button or
//! slider of a panel or window scrolls it. Those widgets keep the drag for themselves (the layer
//! rows, the swatches), so before this only the thin scroll bar scrolled.

pub mod buttons;
pub mod gestures;
pub mod settings;
pub mod ui;
pub mod virtual_keys;

use std::path::PathBuf;
use std::time::Duration;

use egui::{Event, PointerButton, pos2};
use vectorcraft_ui_egui::VectorcraftApp;
use vectorcraft_ui_egui::canvas::Xf;

use buttons::{ButtonState, Out};
use gestures::{Gestures, Phase};
pub use settings::{DeviceKind, PenButtonCfg, PenTouchSettings, RECENT, SoftKey};
pub use virtual_keys::VirtualKeys;

/// Set in the touch id of a contact made by a stylus tip.
pub const PEN_TOUCH_FLAG: u64 = 1 << 48;
/// Set in the touch id of a contact made by a stylus's eraser end.
pub const ERASER_TOUCH_FLAG: u64 = 1 << 49;

/// Is this touch id a stylus contact? (On Android every finger reports pressure, so only the id
/// flag counts.)
pub fn is_pen_id(id: u64) -> bool {
    id & (PEN_TOUCH_FLAG | ERASER_TOUCH_FLAG) != 0
}

/// The height the standard controls get with "Larger touch targets" (points).
const COMFORT_HEIGHT: f32 = 30.0;
/// What the app's theme gives them otherwise.
const NORMAL_HEIGHT: f32 = 24.0;

/// Tools whose drag draws something, so a finger on an active-stylus screen should not use them
/// (it borrows the Selection tool instead and moves things).
const DRAWING_TOOLS: &[&str] = &[
    "paintbrush",
    "blobBrush",
    "shaper",
    "pencil",
    "smooth",
    "pathEraser",
    "eraser",
    "knife",
    "lineSegment",
    "arc",
    "spiral",
    "rectangularGrid",
    "polarGrid",
    "rectangle",
    "roundedRectangle",
    "ellipse",
    "polygon",
    "star",
    "flare",
];

/// A touch contact being followed.
#[derive(Clone, Copy, Debug)]
struct Contact {
    id: u64,
    pen: bool,
    /// A finger that landed on the canvas in pen only mode: the tools never see it.
    blocked: bool,
    /// It landed on the canvas (not on a panel, menu or window).
    canvas: bool,
    /// Where it was last seen (a lone blocked finger pans the view by what it moved; a scrolling
    /// finger scrolls by what it moved).
    last: egui::Pos2,
    /// Where and when it landed.
    press: egui::Pos2,
    started: f64,
    /// A swipe on a panel or window that this module turned into scrolling.
    scroll: bool,
}

/// How long the fingers of a tap may stay down, in seconds.
const TAP_TIME: f64 = 0.5;
/// How far (points) a finger of a tap may move: further, it is a pan or a pinch.
const TAP_SLOP: f32 = 16.0;

/// Taps of two or three blocked fingers (pen only mode): two undo, three redo.
#[derive(Clone, Debug, Default)]
struct Taps {
    down: Vec<(u64, egui::Pos2)>,
    most: usize,
    start: f64,
    spoilt: bool,
}

impl Taps {
    /// Follow a blocked finger; `Some(n)` when all fingers lifted from a tap of `n` (two or more).
    fn feed(&mut self, id: u64, phase: Phase, pos: egui::Pos2, now: f64) -> Option<usize> {
        match phase {
            Phase::Start => {
                if self.down.is_empty() {
                    *self = Self { start: now, ..Self::default() };
                }
                if !self.down.iter().any(|(d, _)| *d == id) && self.down.len() < 16 {
                    self.down.push((id, pos));
                }
                self.most = self.most.max(self.down.len());
                None
            }
            Phase::Move => {
                if self.down.iter().any(|(d, at)| *d == id && at.distance(pos) > TAP_SLOP) {
                    self.spoilt = true;
                }
                None
            }
            Phase::End => {
                let known = self.down.len();
                self.down.retain(|(d, _)| *d != id);
                if self.down.len() == known {
                    return None;
                }
                self.spoilt |= now - self.start > TAP_TIME;
                (self.down.is_empty() && !self.spoilt && self.most >= 2).then_some(self.most)
            }
        }
    }

    fn clear(&mut self) {
        *self = Self::default();
    }
}

#[derive(Debug, Default)]
pub struct PenTouch {
    pub settings: PenTouchSettings,
    /// The settings as last written to the file.
    saved: Option<PenTouchSettings>,
    file: Option<PathBuf>,
    pub keys: VirtualKeys,
    buttons: [ButtonState; 2],
    gestures: Gestures,
    contacts: Vec<Contact>,

    // ---- barrel buttons
    /// The tool a tool-key tap left, per button.
    tool_before: [Option<&'static str>; 2],
    /// Frames since a tool key was sent, per button, while checking that it changed the tool.
    tool_check: [Option<u32>; 2],
    restore_tool: Vec<&'static str>,

    /// Where the pen is (hovering or touching) and when it was last seen, for the pointer ring.
    pen_pos: Option<egui::Pos2>,
    pen_seen: f64,
    pen_touching: bool,
    /// The tool in use and the one before it ("switch between recent tools").
    recent: [Option<&'static str>; 2],
    /// A "switch to the previous tool" was asked for (by a pen button or a soft key).
    switch_recent: bool,

    /// The last frame's finger gesture.
    pub frame: Option<gestures::Frame>,
    /// A pen contact whose pointer press this module built itself (pen only mode).
    synth_pen: Option<u64>,
    taps: Taps,
    /// Commands to run once the frame's input is in (undo and redo of finger taps).
    commands: Vec<&'static str>,

    // ---- fingers on an active-stylus screen
    finger_tool_before: Option<&'static str>,
    /// Frames since the finger that borrowed the tool lifted (the tool goes back one frame later,
    /// so the finger's release still reaches the tool it used).
    finger_tool_idle: u8,

    comfort_on: bool,
    pub(crate) prompt: ui::Prompt,
    /// The Pen & Touch window is open.
    pub window_open: bool,
}

impl PenTouch {
    /// The settings from `file` (defaults when it is missing or unreadable).
    pub fn load(file: Option<PathBuf>) -> Self {
        let value = file
            .as_ref()
            .and_then(|f| std::fs::read(f).ok())
            .and_then(|bytes| serde_json::from_slice::<serde_json::Value>(&bytes).ok())
            .unwrap_or(serde_json::Value::Null);
        let settings = PenTouchSettings::from_json(&value);
        Self { saved: Some(settings.clone()), settings, file, ..Self::default() }
    }

    /// Write the settings when they changed. Cheap: one struct compare per frame.
    pub fn persist(&mut self) {
        if self.saved.as_ref() == Some(&self.settings) {
            return;
        }
        self.saved = Some(self.settings.clone());
        let Some(path) = self.file.as_deref() else { return };
        if let Some(dir) = path.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        if let Ok(bytes) = serde_json::to_vec_pretty(&self.settings.to_json()) {
            // Best effort: a failed write keeps the previous file.
            let _ = vectorcraft_engine::cmd::fileio::write_atomic(path, &bytes);
        }
    }

    /// Ask for the previous tool (the "Switch between recent tools" action).
    pub fn switch_to_recent_tool(&mut self) {
        self.switch_recent = true;
    }

    /// Report a stylus barrel button from a source that does not use the mouse-button mapping.
    /// `index` 0 is the first button, 1 the second.
    pub fn pen_button(&mut self, index: usize, pressed: bool, now: f64) -> Vec<Out> {
        let (Some(cfg), Some(state)) = (button_cfg(&self.settings, index), self.buttons.get_mut(index)) else { return Vec::new() };
        if pressed { state.press(cfg, now) } else { state.release(cfg, now) }
    }

    /// Is pen only mode on?
    pub fn stylus_only(&self) -> bool {
        self.settings.stylus_only()
    }

    /// The Finger / Pen only button: flip the mode.
    pub fn toggle_input_mode(&mut self) {
        self.settings.input_mode = self.settings.input_mode.toggled();
        self.gestures.reset();
        self.contacts.clear();
        self.synth_pen = None;
        self.taps.clear();
    }

    /// Let go of the keys the pen buttons and soft keys hold (a button's settings changed).
    pub fn release_held(&mut self) {
        for b in &mut self.buttons {
            let _ = b.cancel();
        }
        self.keys.release_all();
    }

    /// Let go of everything simulated.
    pub fn release_everything(&mut self) {
        self.release_held();
        self.gestures.reset();
        self.contacts.clear();
        self.synth_pen = None;
        self.taps.clear();
    }

    fn contact(&self, id: u64) -> Option<Contact> {
        self.contacts.iter().find(|c| c.id == id).copied()
    }
}

fn button_cfg(s: &PenTouchSettings, index: usize) -> Option<&PenButtonCfg> {
    match index {
        0 => Some(&s.button1),
        1 => Some(&s.button2),
        _ => None,
    }
}

/// Once per frame, before the interface: finish what the raw input started (put tools back, run
/// the finger taps' commands) and keep the settings applied and saved.
pub fn logic(pt: &mut PenTouch, app: &mut VectorcraftApp, ctx: &egui::Context) {
    switch_recent_tool(pt, app);
    // Pen button tool memory: back to the previous tool; and give up when a key changed nothing.
    for tool in std::mem::take(&mut pt.restore_tool) {
        app.select_tool(tool);
    }
    for index in 0..2 {
        let Some(frames) = pt.tool_check.get(index).copied().flatten() else { continue };
        let before = pt.tool_before.get(index).copied().flatten();
        if frames >= 3 {
            if before == Some(app.session.tool_id())
                && let Some(b) = pt.buttons.get_mut(index)
            {
                b.disarm_toggle();
                if let Some(slot) = pt.tool_before.get_mut(index) {
                    *slot = None;
                }
            }
            if let Some(slot) = pt.tool_check.get_mut(index) {
                *slot = None;
            }
        } else if let Some(slot) = pt.tool_check.get_mut(index) {
            *slot = Some(frames + 1);
        }
    }
    for command in std::mem::take(&mut pt.commands) {
        if let Err(error) = app.run(command, serde_json::json!({})) {
            log::warn!("{command}: {error}");
        }
    }
    comfort(pt, ctx);
    pt.persist();
}

/// "Larger touch targets": the standard controls (buttons, fields, drag values) get a taller
/// minimum size. Only raised, never lowered below what the theme gives, and put back when off.
fn comfort(pt: &mut PenTouch, ctx: &egui::Context) {
    if pt.settings.touch_comfort {
        pt.comfort_on = true;
        ctx.global_style_mut(|s| {
            if s.spacing.interact_size.y < COMFORT_HEIGHT {
                s.spacing.interact_size.y = COMFORT_HEIGHT;
            }
        });
    } else if pt.comfort_on {
        pt.comfort_on = false;
        ctx.global_style_mut(|s| {
            if (s.spacing.interact_size.y - COMFORT_HEIGHT).abs() < 0.01 {
                s.spacing.interact_size.y = NORMAL_HEIGHT;
            }
        });
    }
}

/// Follow the tool in use, and go to the one before it when asked. A tool a finger borrows
/// (Selection while it drags) is not a choice and is left out of the history.
fn switch_recent_tool(pt: &mut PenTouch, app: &mut VectorcraftApp) {
    let tool = app.session.tool_id();
    let borrowed = pt.finger_tool_before.is_some();
    if !borrowed && pt.recent[0] != Some(tool) {
        pt.recent[1] = pt.recent[0];
        pt.recent[0] = Some(tool);
    }
    if !std::mem::take(&mut pt.switch_recent) {
        return;
    }
    if let Some(previous) = pt.recent[1].filter(|t| *t != tool) {
        app.select_tool(previous);
    }
}

/// Add this frame's simulated input to `raw` and follow the touch contacts. Called from the
/// shell's `raw_input_hook`, before the app's own.
pub fn raw_input(pt: &mut PenTouch, app: &mut VectorcraftApp, ctx: &egui::Context, raw: &mut egui::RawInput) {
    let now = raw.time.unwrap_or(0.0);

    // Focus lost: nothing may stay held.
    if raw.events.iter().any(|e| matches!(e, Event::WindowFocused(false))) {
        pt.release_everything();
    }

    pen_buttons(pt, app, ctx, raw, now);
    track_pen_pointer(pt, raw, now);
    touches(pt, app, ctx, raw);
    pt.keys.inject(raw);
    if pt.keys.busy() {
        ctx.request_repaint();
    }
}

/// Follow the pen for the pointer ring: its touch contacts, and its hover (which the platform layer
/// reports as pointer moves in a frame that has no touch events and no finger down).
fn track_pen_pointer(pt: &mut PenTouch, raw: &egui::RawInput, now: f64) {
    if !pt.settings.show_pen_pointer {
        pt.pen_pos = None;
        return;
    }
    let touch_frame = raw.events.iter().any(|e| matches!(e, Event::Touch { .. }));
    let finger_down = pt.contacts.iter().any(|c| !c.pen);
    for e in &raw.events {
        match e {
            Event::Touch { id, phase, pos, .. } if is_pen_id(id.0) => {
                pt.pen_pos = Some(*pos);
                pt.pen_seen = now;
                pt.pen_touching = !matches!(phase, egui::TouchPhase::End | egui::TouchPhase::Cancel);
            }
            Event::PointerMoved(pos) if !touch_frame && !finger_down => {
                pt.pen_pos = Some(*pos);
                pt.pen_seen = now;
            }
            Event::PointerGone => pt.pen_pos = None,
            _ => {}
        }
    }
}

/// The ring's diameter: the Blob Brush's or Eraser's size on screen, or the size from the settings.
fn pointer_diameter(pt: &PenTouch, app: &VectorcraftApp) -> f32 {
    let s = &pt.settings;
    if s.pen_pointer_follows_brush
        && matches!(app.session.tool_id(), "blobBrush" | "eraser")
        && let Some(view) = app.view()
        && let Some(size) = app.session.tool_options().get("size").and_then(|v| v.as_f64())
    {
        let d = (size * view.zoom) as f32;
        if d.is_finite() {
            return d.clamp(6.0, 800.0);
        }
    }
    s.pointer_diameter()
}

/// Draw the pointer ring where the pen is. Called at the end of the frame.
pub fn paint_pen_pointer(pt: &PenTouch, app: &VectorcraftApp, ctx: &egui::Context) {
    let Some(pos) = pt.pen_pos.filter(|_| pt.settings.show_pen_pointer) else { return };
    let now = ctx.input(|i| i.time);
    // A hover the platform stopped reporting (the pen left the screen) fades out.
    let age = now - pt.pen_seen;
    if age > 1.5 && !pt.pen_touching {
        return;
    }
    let r = pointer_diameter(pt, app) / 2.0;
    let painter = ctx.layer_painter(egui::LayerId::new(egui::Order::Tooltip, egui::Id::new("pen-touch-pointer")));
    if pt.pen_touching {
        painter.circle_filled(pos, r, egui::Color32::from_rgba_unmultiplied(255, 255, 255, 40));
    }
    painter.circle_stroke(pos, r, egui::Stroke::new(3.0, egui::Color32::from_black_alpha(160)));
    painter.circle_stroke(pos, r, egui::Stroke::new(1.5, egui::Color32::WHITE));
    painter.circle_filled(pos, 2.0, egui::Color32::WHITE);
    ctx.request_repaint_after(Duration::from_millis(250));
}

/// Barrel buttons: the Back/Forward mouse buttons the platform layer maps them to.
fn pen_buttons(pt: &mut PenTouch, app: &mut VectorcraftApp, ctx: &egui::Context, raw: &mut egui::RawInput, now: f64) {
    let enabled = [pt.settings.button1.enabled, pt.settings.button2.enabled];
    let mut events: Vec<(usize, bool)> = Vec::new();
    raw.events.retain(|e| match e {
        Event::PointerButton { button: b @ (PointerButton::Extra1 | PointerButton::Extra2), pressed, .. } => {
            let index = usize::from(*b == PointerButton::Extra2);
            if enabled[index] {
                events.push((index, *pressed));
                false
            } else {
                true
            }
        }
        _ => true,
    });
    for (index, pressed) in events {
        let outs = pt.pen_button(index, pressed, now);
        carry_out(pt, app, index, outs);
    }
    for index in 0..2 {
        let Some(cfg) = button_cfg(&pt.settings, index).cloned() else { continue };
        let Some(state) = pt.buttons.get_mut(index) else { continue };
        if !cfg.enabled {
            let outs = state.cancel();
            carry_out(pt, app, index, outs);
            continue;
        }
        let outs = state.tick(&cfg, now);
        let waiting = state.waiting();
        carry_out(pt, app, index, outs);
        if waiting {
            ctx.request_repaint_after(Duration::from_millis(40));
        }
    }
}

fn carry_out(pt: &mut PenTouch, app: &VectorcraftApp, index: usize, outs: Vec<Out>) {
    for out in outs {
        match out {
            Out::Tap(spec) if spec == RECENT => pt.switch_recent = true,
            Out::Tap(spec) => pt.keys.tap(&spec),
            Out::ToolKey(spec) => {
                if let Some(slot) = pt.tool_before.get_mut(index) {
                    *slot = Some(app.session.tool_id());
                }
                if let Some(slot) = pt.tool_check.get_mut(index) {
                    *slot = Some(0);
                }
                pt.keys.tap(&spec);
            }
            Out::RestoreTool => {
                if let Some(tool) = pt.tool_before.get_mut(index).and_then(Option::take) {
                    pt.restore_tool.push(tool);
                }
                if let Some(slot) = pt.tool_check.get_mut(index) {
                    *slot = None;
                }
            }
            Out::Latch(spec) => pt.keys.latch(&spec),
            Out::Press(spec) => pt.keys.press(&spec),
            Out::Release(spec) => pt.keys.release(&spec),
        }
    }
}

/// Where a finger counts as "on the canvas": inside the canvas and not over a window or popup.
fn on_canvas(ctx: &egui::Context, canvas: Option<egui::Rect>, pos: egui::Pos2) -> bool {
    canvas.is_some_and(|r| r.contains(pos)) && ctx.layer_id_at(pos).is_none_or(|l| l.order == egui::Order::Background)
}

/// May a swipe that started at `pos` scroll what is there? Yes when the widget on top is a short
/// row, button, thumbnail or slider. Drag-only grips (title bars, scroll bars), narrow handles (the
/// eye and lock columns of the Layers panel) and tall fields such as colour pickers keep their own
/// drag.
fn scroll_target(ctx: &egui::Context, pos: egui::Pos2) -> bool {
    let layer = ctx.layer_id_at(pos).unwrap_or_else(egui::LayerId::background);
    ctx.viewport(|v| {
        v.prev_pass
            .widgets
            .get_layer(layer)
            .filter(|w| w.enabled && (w.sense.senses_click() || w.sense.senses_drag()) && w.interact_rect.contains(pos))
            .last()
            .is_some_and(|w| {
                let r = w.rect;
                // Drag-only grips (window title bars, scroll bar handles) keep their drag, and so
                // do narrow handles (sweeping the eye column).
                let grip = w.sense.senses_drag() && ((!w.sense.senses_click() && r.width() > r.height() * 1.5) || r.width() < 24.0);
                r.height() < 64.0 && !grip
            })
    })
}

/// Follow the touch contacts: gestures, pen only mode, swipe scrolling, the finger tool.
fn touches(pt: &mut PenTouch, app: &mut VectorcraftApp, ctx: &egui::Context, raw: &mut egui::RawInput) {
    let now = raw.time.unwrap_or(0.0);
    let touch_scroll = pt.settings.touch_scroll;
    // Events that turn a swipe on a panel into scrolling, and whether any swipe is scrolling.
    let mut inject: Vec<Event> = Vec::new();
    let mut scrolling_any = false;
    let stylus_only = pt.settings.stylus_only();
    // Only with a document open: the canvas rectangle of the home screen is stale.
    let canvas = if app.session.active().is_some() { app.canvas_rect } else { None };
    let mut blocked_seen = false;
    // The pen's own contact events this frame, for rebuilding its pointer: (id, phase, pos).
    let mut pen_events: Vec<(u64, Phase, egui::Pos2)> = Vec::new();
    let mut blocked_ids: Vec<u64> = Vec::new();
    // What a lone blocked finger moved this frame: (where it was, where it is).
    let mut one_finger: Option<(egui::Pos2, egui::Pos2)> = None;
    let mut tap_fingers: Option<usize> = None;

    for e in &raw.events {
        let Event::Touch { id, phase, pos, .. } = e else { continue };
        let id = id.0;
        let pos = *pos;
        let phase = match phase {
            egui::TouchPhase::Start => Phase::Start,
            egui::TouchPhase::Move => Phase::Move,
            egui::TouchPhase::End | egui::TouchPhase::Cancel => Phase::End,
        };
        let contact = match phase {
            Phase::Start => {
                let pen = is_pen_id(id);
                let blocked = stylus_only && !pen && on_canvas(ctx, canvas, pos);
                let c = Contact { id, pen, blocked, canvas: on_canvas(ctx, canvas, pos), last: pos, press: pos, started: now, scroll: false };
                pt.contacts.retain(|x| x.id != id);
                if pt.contacts.len() >= 16 {
                    pt.contacts.remove(0);
                }
                pt.contacts.push(c);
                Some(c)
            }
            _ => pt.contact(id),
        };
        // A move for a contact never seen to start is a hovering pen, no finger.
        let Some(c) = contact else { continue };
        // A vertical swipe that starts on a row or slider of a panel or window scrolls it.
        let mut scrolling = c.scroll;
        if touch_scroll && !c.pen && !c.canvas && !c.blocked {
            let mut from = c.last;
            if phase == Phase::Move && !scrolling && now - c.started <= 0.6 {
                let d = pos - c.press;
                if d.y.abs() >= 8.0 && d.y.abs() > 1.4 * d.x.abs() && scroll_target(ctx, c.press) {
                    scrolling = true;
                    from = c.press;
                    // Let go of the press far away: the widget under it gets no click and no drag.
                    let far = pos2(-10_000.0, -10_000.0);
                    inject.push(Event::PointerMoved(far));
                    inject.push(Event::PointerButton { pos: far, button: PointerButton::Primary, pressed: false, modifiers: Default::default() });
                }
            }
            if scrolling && phase == Phase::Move {
                inject.push(Event::PointerMoved(pos));
                inject.push(Event::MouseWheel {
                    unit: egui::MouseWheelUnit::Point,
                    delta: pos - from,
                    phase: egui::TouchPhase::Move,
                    modifiers: Default::default(),
                });
            }
            if scrolling && phase == Phase::End {
                inject.push(Event::PointerGone);
            }
            if let Some(slot) = pt.contacts.iter_mut().find(|x| x.id == id) {
                slot.scroll = scrolling;
                if scrolling {
                    slot.last = pos;
                }
            }
        }
        scrolling_any |= scrolling;
        if phase == Phase::End {
            pt.contacts.retain(|x| x.id != id);
        }
        pt.gestures.touch(id, phase, [pos.x, pos.y], c.pen);
        if c.blocked {
            if let Some(n) = pt.taps.feed(id, phase, pos, now) {
                tap_fingers = Some(n);
            }
            if phase == Phase::Move
                && let Some(slot) = pt.contacts.iter_mut().find(|x| x.id == id)
            {
                let from = std::mem::replace(&mut slot.last, pos);
                one_finger = Some(match one_finger {
                    Some((first, _)) => (first, pos),
                    None => (from, pos),
                });
            }
            blocked_seen = true;
            blocked_ids.push(id);
        }
        if c.pen {
            pen_events.push((id, phase, pos));
        }
    }

    if scrolling_any {
        // The scrolling finger is no pointer: its own press, moves and release go, ours come.
        raw.events.retain(|e| !matches!(e, Event::PointerMoved(_) | Event::PointerButton { .. } | Event::PointerGone));
        raw.events.extend(inject);
        ctx.request_repaint();
    }

    let frame = pt.gestures.end_frame();
    pt.frame = Some(frame);

    finger_tool(pt, app, ctx);

    if !stylus_only {
        pt.synth_pen = None;
        return;
    }

    // A tap of two fingers undoes, one of three redoes (Enable Touch Gestures).
    if let Some(n) = tap_fingers
        && app.session.prefs.touch_gestures
    {
        match n {
            2 => pt.commands.push("edit.undo"),
            3 => pt.commands.push("edit.redo"),
            _ => {}
        }
        ctx.request_repaint();
    }

    // Two fingers on the canvas move the view.
    if frame.is_gesture() && frame.moved() && canvas.is_some_and(|r| r.contains(pos2(frame.mid[0], frame.mid[1]))) {
        let blocked_pair = pt.contacts.iter().filter(|c| c.blocked).count() >= 2;
        if blocked_pair {
            navigate(&pt.settings, app, &frame);
            ctx.request_repaint();
        }
    }

    // One finger on the canvas pans it.
    if let Some((from, to)) = one_finger
        && pt.settings.stylus_only_pan
        && !frame.is_gesture()
        && pt.contacts.iter().filter(|c| c.blocked).count() == 1
        && from != to
    {
        let pan = gestures::Frame { scale: 1.0, rotation: 0.0, mid: [to.x, to.y], prev_mid: [from.x, from.y], ..frame };
        navigate(&pt.settings, app, &pan);
        ctx.request_repaint();
    }

    // The tools never see a blocked finger. While one is down, egui's pointer belongs to it, so the
    // pen's pointer is rebuilt from its own touch events.
    let blocked_down = pt.contacts.iter().any(|c| c.blocked);
    let replace = blocked_seen || blocked_down || pt.synth_pen.is_some();
    if !replace {
        return;
    }
    raw.events.retain(|e| match e {
        Event::Touch { id, phase, .. } => matches!(phase, egui::TouchPhase::End | egui::TouchPhase::Cancel) || !blocked_ids.contains(&id.0),
        Event::PointerMoved(_) | Event::PointerButton { .. } => false,
        _ => true,
    });
    let modifiers = pt.keys.held_modifiers();
    for (id, phase, pos) in pen_events {
        match phase {
            Phase::Start => {
                pt.synth_pen = Some(id);
                raw.events.push(Event::PointerMoved(pos));
                raw.events.push(Event::PointerButton { pos, button: PointerButton::Primary, pressed: true, modifiers });
            }
            Phase::Move => {
                if pt.synth_pen == Some(id) {
                    raw.events.push(Event::PointerMoved(pos));
                }
            }
            Phase::End => {
                if pt.synth_pen == Some(id) {
                    pt.synth_pen = None;
                    raw.events.push(Event::PointerMoved(pos));
                    raw.events.push(Event::PointerButton { pos, button: PointerButton::Primary, pressed: false, modifiers });
                }
            }
        }
    }
}

fn wrap_degrees(a: f64) -> f64 {
    let r = (a + 180.0).rem_euclid(360.0) - 180.0;
    if r.is_finite() { r } else { 0.0 }
}

/// Pan, zoom and rotate the active view by what the fingers did, keeping the document point that
/// was under their midpoint under it.
fn navigate(s: &PenTouchSettings, app: &mut VectorcraftApp, frame: &gestures::Frame) {
    let Some(rect) = app.canvas_rect else { return };
    let Some(view) = app.view_mut() else { return };
    let (prev, mid) = (pos2(frame.prev_mid[0], frame.prev_mid[1]), pos2(frame.mid[0], frame.mid[1]));
    let anchor = Xf::new(rect, view).to_doc(prev);
    if s.stylus_only_zoom && frame.scale.is_finite() && frame.scale > 0.0 {
        view.zoom = (view.zoom * f64::from(frame.scale)).clamp(0.0313, 640.0);
    }
    if s.stylus_only_rotate && frame.rotation.is_finite() {
        view.rotation = wrap_degrees(view.rotation + f64::from(frame.rotation).to_degrees());
    }
    let target = if s.stylus_only_pan { mid } else { prev };
    view.center += anchor - Xf::new(rect, view).to_doc(target);
    view.fitted = true;
}

/// An active-stylus screen: a finger is the Selection tool while it is down, the pen keeps
/// drawing. Not in pen only mode, where a finger works no tool at all.
fn finger_tool(pt: &mut PenTouch, app: &mut VectorcraftApp, ctx: &egui::Context) {
    // Only a finger that landed on the canvas: one on a panel or window (scrolling the swatches or
    // layers list) must not change the tool under it.
    let on_canvas = pt.contacts.iter().any(|c| !c.pen && c.canvas);
    let pen_down = pt.contacts.iter().any(|c| c.pen);
    if !pt.settings.finger_move_on() || pt.settings.stylus_only() || !on_canvas {
        if pt.finger_tool_before.is_some() {
            // Put the tool back one frame after the finger lifted.
            if pt.finger_tool_idle >= 1 {
                restore_finger_tool(pt, app);
            } else {
                pt.finger_tool_idle += 1;
                ctx.request_repaint();
            }
        }
        return;
    }
    pt.finger_tool_idle = 0;
    if pt.finger_tool_before.is_none() && !pen_down && finger_move_applies(app) {
        pt.finger_tool_before = Some(app.session.tool_id());
        app.select_tool("selection");
    }
}

/// Put the tool back, unless the user picked another one meanwhile.
fn restore_finger_tool(pt: &mut PenTouch, app: &mut VectorcraftApp) {
    pt.finger_tool_idle = 0;
    if let Some(tool) = pt.finger_tool_before.take()
        && app.session.tool_id() == "selection"
    {
        app.select_tool(tool);
    }
}

/// Where a finger may borrow the Selection tool: only from a tool whose drag draws, and not while a
/// dialog is open.
fn finger_move_applies(app: &VectorcraftApp) -> bool {
    DRAWING_TOOLS.contains(&app.session.tool_id()) && app.ui.dialog.is_none() && app.session.active().is_some()
}
