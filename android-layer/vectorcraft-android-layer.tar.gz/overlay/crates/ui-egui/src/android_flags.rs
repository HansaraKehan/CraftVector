//! Flags the Android build's Help menu items set and the Android app reads (and clears) each frame.

use std::sync::atomic::AtomicBool;

/// Help > Check for Updates…
pub static CHECK_UPDATES: AtomicBool = AtomicBool::new(false);
/// Help > Quick tour: pen and touch…
pub static START_TOUR: AtomicBool = AtomicBool::new(false);
