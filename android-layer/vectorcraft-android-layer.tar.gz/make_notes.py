#!/usr/bin/env python3
"""Turn whats-new.md into release notes and the README feature list. Run by the workflow, rarely edited.

  make_notes.py whats-new.md --prev-body prev.md --out android-section.md [--readme README.md]

Writes the notes section ("## What's new on Android") unless the previous release already carries this
section's hash marker, and (with --readme) rewrites the block between the android-features markers."""
import argparse
import hashlib
import re
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("news")
ap.add_argument("--prev-body", default="")
ap.add_argument("--out", required=True)
ap.add_argument("--readme", default="")
a = ap.parse_args()

text = Path(a.news).read_text(encoding="utf-8")
text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
sections = re.split(r"(?m)^## ", text)[1:]
Path(a.out).write_text("", encoding="utf-8")


def clean(line: str) -> str:
    """No notifications (@name) and no issue links (#123) in anything that reaches GitHub."""
    line = re.sub(r"(?<!`)@(\w)", "\uff20\\1", line)
    return re.sub(r"#(\d+)", r"\\#\1", line)


if sections:
    first = sections[0]
    digest = hashlib.sha256(first.strip().encode()).hexdigest()[:10]
    marker = f"<!-- android-news:{digest} -->"
    prev = Path(a.prev_body).read_text(encoding="utf-8") if a.prev_body and Path(a.prev_body).exists() else ""
    items = [clean(l) for l in first.splitlines()[1:] if l.startswith(("- ", "* "))]
    if marker in prev or not items:
        print("Android news: already in the previous release, not repeated")
    else:
        feats = [l for l in items if l.startswith("- ")]
        fixes = [l for l in items if l.startswith("* ")]
        out = ["## What's new on Android", ""]
        out += feats
        if fixes:
            out += ["", "**Fixes**", ""] + ["- " + f[2:] for f in fixes]
        out += ["", marker, ""]
        Path(a.out).write_text("\n".join(out), encoding="utf-8")
        print(f"Android news: {len(feats)} feature(s), {len(fixes)} fix(es)")

if a.readme and Path(a.readme).exists():
    readme = Path(a.readme).read_text(encoding="utf-8")
    start, end = "<!-- android-features:start -->", "<!-- android-features:end -->"
    if start in readme and end in readme:
        names = []
        for sec in sections:
            for l in sec.splitlines():
                m = re.match(r"- \*\*(.+?)\.?\*\*\s*(.*)", l)
                if m and m.group(1) not in names:
                    names.append(m.group(1))
        block = "\n".join(f"- {n}" for n in names)
        new = re.sub(re.escape(start) + r".*?" + re.escape(end), lambda _: f"{start}\n{block}\n{end}", readme, flags=re.S)
        if new != readme:
            Path(a.readme).write_text(new, encoding="utf-8")
            print("README feature list updated")
