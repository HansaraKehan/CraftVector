#!/usr/bin/env python3
"""Add the Android layer to a VectorCraft checkout. Run from the repository root."""
import os
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def developer_url() -> str:
    """The profile of whoever owns the repository this is built in (their GitHub account)."""
    owner = (os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/x").split("/")[0]
    return f"https://github.com/{owner}"


def sub_all(path: Path, pairs: list, label: str) -> None:
    """Replace text in a source file, everywhere it occurs, and say how many changes were made."""
    if not path.exists():
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    changes = 0
    for old, new in pairs:
        changes += text.count(old)
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8")
    print(f"{label}: {changes} change(s)")


def drop_in_patch_section(text: str, names: list[str]) -> str:
    """Remove `name = ...` lines of those crates from [patch.crates-io] only (never from [workspace.dependencies])."""
    found = re.search(r"(?m)^\[patch\.crates-io\]\s*$", text)
    if not found:
        return text
    start = found.end()
    following = re.search(r"(?m)^\[", text[start:])
    end = start + following.start() if following else len(text)
    section = re.sub(r"(?m)^(" + "|".join(names) + r")\s*=.*\n", "", text[start:end])
    return text[:start] + section + text[end:]


def patch_workspace() -> None:
    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if 'exclude = ["vendor/winit"]' not in text:
        i = text.find("members = [")
        if i < 0:
            sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/winit"]\n' + text[j + 1 :]
    line = 'winit = { path = "vendor/winit" }'
    if "[patch.crates-io]" in text:
        # Upstream already patches some crates: add ours to that table (replacing its own winit entry, if any).
        text = drop_in_patch_section(text, ["winit"])
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + line + "\n", 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: keep winit but restore hardware mouse, wheel and keyboard events.\n[patch.crates-io]\n" + line + "\n"
    cargo.write_text(text, encoding="utf-8")


def add_releases_link() -> None:
    """A link to this repository's Releases page in the About / Home links."""
    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftVector"
    url = f"https://github.com/{repo}/releases"
    community = ROOT / "crates/ui-egui/src/community.rs"
    if not community.exists():
        print("Releases link added to: nowhere (community.rs not found)")
        return
    text = community.read_text(encoding="utf-8")
    anchor = '    link(app, ui, "git-branch", tl!("Source code on GitHub"), "help.github", &s("github"));\n}'
    if anchor in text and "Get the Android app" not in text:
        text = text.replace(anchor, anchor[:-2] + f'\n    ui.hyperlink_to("Get the Android app / updates", "{url}");\n}}', 1)
        community.write_text(text, encoding="utf-8")
        print(f"Releases link added to: About and Home links ({url})")
    else:
        print("Releases link added to: nowhere (upstream code changed)")



def rebrand() -> None:
    """Replace the upstream community (Discord) link with a link to this build's developer on GitHub.
    The licences, copyright notices and the credit to the original project stay where they are."""
    url = developer_url()
    sub_all(ROOT / "crates/engine/src/cmd/help.rs", [
        ('pub const DISCORD_URL: &str = "https://discord.gg/artcraft";', f'pub const DISCORD_URL: &str = "{url}";'),
        ('"Join Our Discord"', '"Follow the developer on GitHub"'),
        ('the ArtCraft community Discord', "the developer's GitHub profile"),
    ], "Community link")
    ui = ROOT / "crates/ui-egui/src"
    sub_all(ui / "community.rs", [
        ('tl!("Join our Discord")', 'tl!("Follow the developer")'),
        ('proportional(12.0), "Discord")', 'proportional(12.0), "Follow")'),
        ('tl!("Join the ArtCraft community on Discord (discord.gg/artcraft)")', 'tl!("Follow the developer of this Android build on GitHub")'),
        ('Color32::from_rgb(0x58, 0x65, 0xF2)', 'Color32::from_rgb(0x2b, 0x31, 0x37)'),
    ], "Community button")
    sub_all(ui / "menus.rs", [('c("Join Our Discord", "help.discord")', 'c("Follow the developer on GitHub", "help.discord")')], "Help menu")

patch_workspace()
shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
add_releases_link()
rebrand()
print("Android layer applied")
