#!/usr/bin/env python3
"""Add the Android layer to a VectorCraft checkout. Run from the repository root."""
import os
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def patch_workspace() -> None:
    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if 'exclude = ["vendor/winit"]' not in text:
        i = text.find("members = [")
        if i < 0:
            sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/winit"]\n' + text[j + 1 :]
    line = 'winit = { path = "vendor/winit" }'
    if "[patch.crates-io]" in text:
        # Upstream already patches some crates: add ours to that table (replacing its own winit entry, if any).
        text = re.sub(r"(?m)^winit\s*=.*\n", "", text)
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + line + "\n", 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: keep winit but restore hardware mouse, wheel and keyboard events.\n[patch.crates-io]\n" + line + "\n"
    cargo.write_text(text, encoding="utf-8")


def add_releases_link() -> None:
    """A link to this repository's Releases page in the About / Home links."""
    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftVector"
    url = f"https://github.com/{repo}/releases"
    community = ROOT / "crates/ui-egui/src/community.rs"
    if not community.exists():
        print("Releases link added to: nowhere (community.rs not found)")
        return
    text = community.read_text(encoding="utf-8")
    anchor = '    link(app, ui, "git-branch", tl!("Source code on GitHub"), "help.github", &s("github"));\n}'
    if anchor in text and "Get the Android app" not in text:
        text = text.replace(anchor, anchor[:-2] + f'\n    ui.hyperlink_to("Get the Android app / updates", "{url}");\n}}', 1)
        community.write_text(text, encoding="utf-8")
        print(f"Releases link added to: About and Home links ({url})")
    else:
        print("Releases link added to: nowhere (upstream code changed)")


patch_workspace()
shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
add_releases_link()
print("Android layer applied")
