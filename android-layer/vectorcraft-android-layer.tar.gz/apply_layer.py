#!/usr/bin/env python3
"""Add the Android layer to a VectorCraft checkout. Run from the repository root."""
import os
import re
import shutil
import sys
from pathlib import Path

class LayerError(Exception):
    """A step of the layer failed; the message names the file or anchor that moved."""


HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def developer_url() -> str:
    """The profile of whoever owns the repository this is built in (their GitHub account)."""
    owner = (os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/x").split("/")[0]
    return f"https://github.com/{owner}"


def sub_all(path: Path, pairs: list, label: str) -> None:
    """Replace text in a source file, everywhere it occurs, and say how many changes were made."""
    if not path.exists():
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    changes = 0
    for old, new in pairs:
        changes += text.count(old)
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8")
    print(f"{label}: {changes} change(s)")


def drop_in_patch_section(text: str, names: list[str]) -> str:
    """Remove `name = ...` lines of those crates from [patch.crates-io] only (never from [workspace.dependencies])."""
    found = re.search(r"(?m)^\[patch\.crates-io\]\s*$", text)
    if not found:
        return text
    start = found.end()
    following = re.search(r"(?m)^\[", text[start:])
    end = start + following.start() if following else len(text)
    section = re.sub(r"(?m)^(" + "|".join(names) + r")\s*=.*\n", "", text[start:end])
    return text[:start] + section + text[end:]


def fetch_winit(text: str) -> None:
    """Put winit in vendor/winit: the exact copy upstream builds with (its pinned git revision, else
    the crates.io release), then add the Android stylus patch on top."""
    import shutil, subprocess, tarfile, urllib.request, io
    dest = ROOT / "vendor" / "winit"
    if (dest / ".android-patched").exists():
        print("winit: already patched")
        return
    if dest.exists():
        shutil.rmtree(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    found = re.search(r'(?m)^winit\s*=\s*\{([^}\n]*)\}', text[text.find("[patch.crates-io]"):]) if "[patch.crates-io]" in text else None
    git = re.search(r'git\s*=\s*"([^"]+)"', found.group(1)) if found else None
    if git:
        rev = re.search(r'(?:rev|tag|branch)\s*=\s*"([^"]+)"', found.group(1))
        subprocess.run(["git", "clone", "-q", git.group(1), str(dest)], check=True)
        if rev:
            subprocess.run(["git", "-C", str(dest), "checkout", "-q", rev.group(1)], check=True)
        shutil.rmtree(dest / ".git", ignore_errors=True)
        print(f"winit: {git.group(1)} {rev.group(1) if rev else '(default branch)'}")
    else:
        url = "https://static.crates.io/crates/winit/winit-0.30.13.crate"
        data = urllib.request.urlopen(url, timeout=120).read()
        with tarfile.open(fileobj=io.BytesIO(data)) as tar:
            tar.extractall(dest.parent)
        shutil.move(str(dest.parent / "winit-0.30.13"), str(dest))
        print("winit: crates.io 0.30.13")
    patch = HERE / "winit-android-stylus.patch"
    result = subprocess.run(["patch", "-p1", "-F3", "--no-backup-if-mismatch", "-d", str(dest), "-i", str(patch)], capture_output=True, text=True)
    print(result.stdout.strip())
    if result.returncode != 0:
        # Name the file and hunk that moved, so the fix is a one-file job.
        moved = re.findall(r"Hunk #\d+ FAILED at \d+", result.stdout)
        files = re.findall(r"(?m)^patching file (\S+)", result.stdout)
        bad = [f for f in files if re.search(r"(?s)patching file " + re.escape(f) + r"\n(?:(?!patching file).)*FAILED", result.stdout)]
        raise LayerError("The winit Android patch no longer applies to upstream's winit. Moved file(s): "
                         + (", ".join(bad) or "unknown") + f" ({len(moved)} hunk(s) failed)\n" + result.stdout + result.stderr)
    (dest / ".android-patched").write_text("ok\n")


def patch_workspace() -> None:
    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if 'exclude = ["vendor/winit"]' not in text:
        i = text.find("members = [")
        if i < 0:
            raise LayerError("Cargo.toml: the `members = [` line the layer anchors on is gone")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/winit"]\n' + text[j + 1 :]
    line = 'winit = { path = "vendor/winit" }'
    fetch_winit(text)
    if "[patch.crates-io]" in text:
        # Upstream already patches some crates: add ours to that table (replacing its own winit entry, if any).
        text = drop_in_patch_section(text, ["winit"])
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + line + "\n", 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: keep winit but restore hardware mouse, wheel and keyboard events.\n[patch.crates-io]\n" + line + "\n"
    cargo.write_text(text, encoding="utf-8")


def add_releases_link() -> None:
    """A link to this repository's Releases page in the About / Home links."""
    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftVector"
    url = f"https://github.com/{repo}/releases"
    community = ROOT / "crates/ui-egui/src/community.rs"
    if not community.exists():
        print("Releases link added to: nowhere (community.rs not found)")
        return
    text = community.read_text(encoding="utf-8")
    anchor = '    link(app, ui, "git-branch", tl!("Source code on GitHub"), "help.github", &s("github"));\n}'
    if anchor in text and "Get the Android app" not in text:
        text = text.replace(anchor, anchor[:-2] + f'\n    ui.hyperlink_to("Get the Android app / updates", "{url}");\n}}', 1)
        community.write_text(text, encoding="utf-8")
        print(f"Releases link added to: About and Home links ({url})")
    else:
        print("Releases link added to: nowhere (upstream code changed)")



def rebrand() -> None:
    """Replace the upstream community (Discord) link with a link to this build's developer on GitHub.
    The licences, copyright notices and the credit to the original project stay where they are."""
    url = developer_url()
    sub_all(ROOT / "crates/engine/src/cmd/help.rs", [
        ('pub const DISCORD_URL: &str = "https://discord.gg/artcraft";', f'pub const DISCORD_URL: &str = "{url}";'),
        ('"Join Our Discord"', '"Follow the developer on GitHub"'),
        ('the ArtCraft community Discord', "the developer's GitHub profile"),
    ], "Community link")
    ui = ROOT / "crates/ui-egui/src"
    sub_all(ui / "community.rs", [
        ('tl!("Join our Discord")', 'tl!("Follow the developer")'),
        ('proportional(12.0), "Discord")', 'proportional(12.0), "Follow")'),
        ('tl!("Join the ArtCraft community on Discord (discord.gg/artcraft)")', 'tl!("Follow the developer of this Android build on GitHub")'),
        ('Color32::from_rgb(0x58, 0x65, 0xF2)', 'Color32::from_rgb(0x2b, 0x31, 0x37)'),
    ], "Community button")
    patch_menus(ui)


def ui_sources(ui: Path) -> list:
    """Every non-test .rs file of the UI crate (upstream moves code between files, so anchors are
    searched for everywhere instead of in one named file)."""
    return [p for p in sorted(ui.rglob("*.rs")) if "tests" not in p.relative_to(ui).parts and not p.name.startswith("tests")]


def replace_once_anywhere(files: list, old: str, new: str) -> int:
    """Replace `old` by `new` in the files that contain it; return how many replacements were made."""
    done = 0
    for path in files:
        text = path.read_text(encoding="utf-8")
        if old in text:
            done += text.count(old)
            path.write_text(text.replace(old, new), encoding="utf-8")
    return done


def add_flags_module() -> None:
    """The Android app reads flags the menus set (android_flags.rs, from the overlay): declare the module."""
    lib = ROOT / "crates/ui-egui/src/lib.rs"
    text = lib.read_text(encoding="utf-8")
    if "pub mod android_flags;" in text:
        return
    new, n = re.subn(r"(?m)^pub mod (\w+);", "pub mod android_flags;\npub mod \\1;", text, count=1)
    if n == 0:
        raise LayerError("crates/ui-egui/src/lib.rs has no `pub mod` line to anchor the android_flags module on")
    lib.write_text(new, encoding="utf-8")


def patch_menus(ui: Path) -> None:
    """Help menu: the Discord item points to the developer's GitHub; Check for Updates and the pen &
    touch Quick tour set flags the Android app reads (src/android_flags.rs)."""
    files = ui_sources(ui)
    n = replace_once_anywhere(files, 'c("Join Our Discord", "help.discord")', 'c("Follow the developer on GitHub", "help.discord")')
    print(f"Help menu (Discord): {n} change(s)")
    items = ('                c("Check for Updates\u2026", "help.checkUpdates"),\n'
             '                c("Quick tour: pen and touch\u2026", "help.penTouchTour"),\n')
    # Upstream has its own Check for Updates item (it checks upstream's releases, not this APK's):
    # ours takes its place. Without it, ours go after the GitHub link.
    n = replace_once_anywhere(files, '                c("Check for Updates\u2026", "help.checkForUpdates"),\n', items)
    if n == 0:
        n = replace_once_anywhere(files, '                c("VectorCraft on GitHub", "help.github"),\n', '                c("VectorCraft on GitHub", "help.github"),\n' + items)
    print(f"Help menu (Check for Updates, Quick tour): {n} change(s)" + ("" if n else "  WARNING: Help menu not found, the items are missing"))
    handler = ('    if id == "help.checkUpdates" {\n        crate::android_flags::CHECK_UPDATES.store(true, std::sync::atomic::Ordering::Relaxed);\n        return;\n    }\n'
               '    if id == "help.penTouchTour" {\n        crate::android_flags::START_TOUR.store(true, std::sync::atomic::Ordering::Relaxed);\n        return;\n    }\n')
    anchor = '    // Help links: the command returns the URL; a menu click opens it (agents just get the URL).\n'
    n = replace_once_anywhere(files, anchor, handler + anchor)
    print(f"Help menu (click handler): {n} change(s)" + ("" if n else "  WARNING: click handler not found, the items do nothing"))


def step(name: str, required: bool, fn) -> bool:
    """Run one layer step. A required step failing stops the build with a message naming what moved;
    an optional one (branding, menu items) only prints a warning and the build goes on."""
    try:
        fn()
        return True
    except Exception as e:  # noqa: BLE001 - every failure must be reported with its step name
        kind = "LAYER ERROR" if required else "WARNING (optional step skipped)"
        print(f"{kind}: {name}: {e}")
        if required:
            sys.exit(f"The Android layer failed at: {name}\n{e}")
        return False


def copy_overlay() -> None:
    shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)


# Required: without these the app does not build. Optional: nice-to-have edits of upstream's own files.
step("winit patch + Cargo.toml [patch.crates-io]", True, patch_workspace)
step("copy the Android crate (overlay)", True, copy_overlay)
step("android_flags module in ui-egui lib.rs", True, add_flags_module)
step("Releases link in About/Home", False, add_releases_link)
step("Discord to GitHub rebrand + Help menu items", False, rebrand)
print("Android layer applied")
